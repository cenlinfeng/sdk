package com.ddt.h5game;

public class AppConfig {
    public static int loginUrlType=0;
}
