package com.ddt.h5game;

public class Constant {

    public static final String MHTAG = "ddtsdk";


}
