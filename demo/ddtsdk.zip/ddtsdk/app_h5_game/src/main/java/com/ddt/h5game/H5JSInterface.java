package com.ddt.h5game;


public interface H5JSInterface {
    void submitRoleData(String json);
    void payment(String json);
    void exit(String json);
    void getInformation(String json);
}
