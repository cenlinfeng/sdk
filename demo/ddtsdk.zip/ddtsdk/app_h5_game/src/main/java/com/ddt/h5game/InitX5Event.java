package com.ddt.h5game;

/**
 * Created by CZG55 on 2020/9/2.
 */
public class InitX5Event {
    private boolean isInit;

    public InitX5Event(boolean isInit) {
        this.isInit = isInit;
    }

    public boolean isInit() {
        return isInit;
    }
}
