package com.ddtsdk.listener;


public class ApiListenerInfo{

	public  void onSuccess(Object obj){
		
	}

}
