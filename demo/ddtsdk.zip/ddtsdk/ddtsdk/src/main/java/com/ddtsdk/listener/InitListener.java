package com.ddtsdk.listener;

public interface InitListener {
	public void Success(String msg);

	public void fail(String msg);
}
