package com.ddtsdk.model.protocol.bean;

public class RoleMsg {
    public boolean is_popup;

    public boolean isIs_popup() {
        return is_popup;
    }

    public void setIs_popup(boolean is_popup) {
        this.is_popup = is_popup;
    }

    public String getPic_url() {
        return pic_url;
    }

    public void setPic_url(String pic_url) {
        this.pic_url = pic_url;
    }

    public String pic_url;

}
