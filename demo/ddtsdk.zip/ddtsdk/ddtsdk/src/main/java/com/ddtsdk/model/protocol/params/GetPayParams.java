package com.ddtsdk.model.protocol.params;

/**
 * Created by CZG on 2020/4/16.
 */
public class GetPayParams {
    private String amount;

    public GetPayParams(String amount) {
        this.amount = amount;
    }
}
