package com.ddtsdk.model.protocol.params;

/**
 * Created by CZG on 2020/4/16.
 */
public class OnlineTimeParams {
    private int minutetime;  //新增实名参数

    public OnlineTimeParams(int minutetime) {
        this.minutetime = minutetime;
    }
}
