package com.ddtsdk.othersdk.manager;

import android.content.Context;
import android.os.Bundle;

public interface AdInterface {
    void adReport(int event, Context context, Bundle bundle);
}
