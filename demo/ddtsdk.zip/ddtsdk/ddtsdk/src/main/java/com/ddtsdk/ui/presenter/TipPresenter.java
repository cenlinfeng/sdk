package com.ddtsdk.ui.presenter;

import com.ddtsdk.common.base.BasePresenter;
import com.ddtsdk.ui.contract.TipContract;

/**
 * Created by CZG on 2020/5/23.
 */
public class TipPresenter extends BasePresenter<TipContract.View> implements TipContract.Presenter<TipContract.View> {

}
