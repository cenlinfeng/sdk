package com.ddtsdk.utils.oaid;

public interface AppIdsUpdater {
    void onIdsAvalid(String oaid);
}
