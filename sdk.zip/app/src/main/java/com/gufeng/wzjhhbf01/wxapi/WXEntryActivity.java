package com.gufeng.wzjhhbf01.wxapi;

import android.os.Bundle;


import com.ddtsdk.ui.activity.BaseWXEntryActivity;
public class WXEntryActivity extends BaseWXEntryActivity {
    @Override
    protected void onCreate( Bundle bundle) {
        super.onCreate(bundle);
    }
}
