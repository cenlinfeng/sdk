package com.ddtsdk.listener;

public interface IKLExitListener {
	
	public void exitSuccess(String msg);

	public void fail(String msg);

}
