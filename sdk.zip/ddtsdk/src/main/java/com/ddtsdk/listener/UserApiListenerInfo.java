package com.ddtsdk.listener;


public interface UserApiListenerInfo{

	/**
	 * 登出账号的回调
	 * */
    void onLogout(Object obj);
}
