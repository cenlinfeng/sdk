package com.ddtsdk.log;

public class LogTag {
    public static String DEFAULTTAG = "ddtsdk_debug_log";  //日志默认打印tag名
    public static String ADTAG = "ddtsdk_ad_log";   //广告日志打印tag名
}
