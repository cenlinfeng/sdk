package com.ddtsdk.model.data;

public class NotReceive {
/**
 *     {
 *             "id":"25",
 *             "coupon_name":"\u5386\u53f2\u7d2f\u51456\u51cf5.99",
 *             "type":"1",
 *             "condition":"3",
 *             "condition_get":"6.00",
 *             "valid_time":"86400",
 *             "condition_amount":"6.00",
 *             "discount_amount":"5.99",
 *             "status":"1",
 *             "create_time":"1648880491",
 *             "create_user":"13",
 *             "rule_id":"13",
 *             "num":"3",
 *             "start_time":"1648880504",
 *             "end_time":"1649226106"
 *         }
 */

    private String id;
    private String coupon_name;
    private String type;
    private String condition;
    private String condition_get;
    private String valid_time;
    private String condition_amount;
    private String discount_amount;
    private String status;
    private String create_time;
    private String create_user;
    private String rule_id;
    private String num;
    private String start_time;
    private String end_time;


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCoupon_name() {
        return coupon_name;
    }

    public void setCoupon_name(String coupon_name) {
        this.coupon_name = coupon_name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getCondition() {
        return condition;
    }

    public void setCondition(String condition) {
        this.condition = condition;
    }

    public String getCondition_get() {
        return condition_get;
    }

    public void setCondition_get(String condition_get) {
        this.condition_get = condition_get;
    }

    public String getValid_time() {
        return valid_time;
    }

    public void setValid_time(String valid_time) {
        this.valid_time = valid_time;
    }

    public String getCondition_amount() {
        return condition_amount;
    }

    public void setCondition_amount(String condition_amount) {
        this.condition_amount = condition_amount;
    }

    public String getDiscount_amount() {
        return discount_amount;
    }

    public void setDiscount_amount(String discount_amount) {
        this.discount_amount = discount_amount;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getCreate_time() {
        return create_time;
    }

    public void setCreate_time(String create_time) {
        this.create_time = create_time;
    }

    public String getCreate_user() {
        return create_user;
    }

    public void setCreate_user(String create_user) {
        this.create_user = create_user;
    }

    public String getRule_id() {
        return rule_id;
    }

    public void setRule_id(String rule_id) {
        this.rule_id = rule_id;
    }

    public String getNum() {
        return num;
    }

    public void setNum(String num) {
        this.num = num;
    }

    public String getStart_time() {
        return start_time;
    }

    public void setStart_time(String start_time) {
        this.start_time = start_time;
    }

    public String getEnd_time() {
        return end_time;
    }

    public void setEnd_time(String end_time) {
        this.end_time = end_time;
    }
}
