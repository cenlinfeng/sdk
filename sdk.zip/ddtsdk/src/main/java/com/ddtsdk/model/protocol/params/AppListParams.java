package com.ddtsdk.model.protocol.params;

/**
 * Created by CZG on 2020/4/16.
 */
public class AppListParams {
    private String applist;

    public AppListParams(String applist) {
        this.applist = applist;
    }
}
