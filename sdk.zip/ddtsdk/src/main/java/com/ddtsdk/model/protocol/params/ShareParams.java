package com.ddtsdk.model.protocol.params;

/**
 * Created on 2020/10/19.
 */
public class ShareParams {
    private String device_type = "android"; //-苹果:ios，安卓:android， PC端:pc，WAP端：wap-
}
