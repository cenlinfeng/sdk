package com.ddtsdk.othersdk.manager.params;

public class PayParam {
    private String token;
    private String sessionid;
    private int appid;
    private String ord;

    public void setToken(String token) {
        this.token = token;
    }

    public void setSessionid(String sessionid) {
        this.sessionid = sessionid;
    }

    public void setAppid(int appid) {
        this.appid = appid;
    }

    public void setOrd(String ord) {
        this.ord = ord;
    }
}
